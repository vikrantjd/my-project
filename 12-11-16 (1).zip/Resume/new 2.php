

    <!DOCTYPE html>
    <html class="no-js" lang="en">

    <head></head>
    <body class="full-screen-preview">

    <img style="display: none" src="http://themeforest.net/preview_referral.png?ref=freshdesignweb" alt=""></img>
    <div class="preview__header">
        <div class="preview__envato-logo"></div>
        <div class="preview__actions">
            <div class="preview__action--buy"></div>
            <div class="preview__action--close">
                <a href="http://demo.mutationmedia.net/SPLIT/">
                    <i class="e-icon -icon-cancel"></i>
                    <span>

                    Remove Frame

                    </span>
                </a>
            </div>
        </div>
    </div>
    <iframe class="full-screen-preview__frame" frameborder="0" data-view="fullScreenPreview" noresize="noresize" name="preview-frame" src="http://demo.mutationmedia.net/SPLIT/" style="height: 603px;">

    #document
        <!DOCTYPE html>
        <!--

        [if lt IE 7]>      <html class="no-js lt-ie9 lt-ie…

        -->
        <!--

        [if IE 7]>         <html class="no-js lt-ie9 lt-ie…

        -->
        <!--

        [if IE 8]>         <html class="no-js lt-ie9"> <![…

        -->
        <!--

        [if gt IE 8]><!

        -->
        <html class=" js flexbox canvas canvastext webgl no-touch geolocation pos… webworkers applicationcache svg inlinesvg smil svgclippaths">

    <!--

    <![endif]

    -->
    <head></head>
    <body>
        <!--

         Preloader 

        -->
        <div id="loader" style="display: none;"></div>
        <!--

         End preloader

        -->
        <!--

        Wrapper

        -->
        <div id="wrapper" class="margLTop margLBottom" data-easytabs="true">

                                <div class="styler" style="display: block; left: -278px;"></div>
                                <!--

                                Container

                                -->
                                <div class="container">
                                    ::before
                                    <div class="row ">
                                        ::before
                                        <!--

                                        Left content

                                        -->
                                        <div class="col-md-3 nopr left-content"></div>
                                        <!--

                                        End left content

                                        -->
                                        <!--

                                        Right content

                                        -->
                                        <div class="col-md-9 right-content">
                                            <!--

                                            About Tab

                                            -->
                                            <section id="about" class="bgWhite ofsInBottom active" style="display: block;">
                                                <!--

                                                About 

                                                -->
                                                <div class="about">
                                                    <!--

                                                    Main title

                                                    -->
                                                    <div class="main-title"></div>
                                                    <!--

                                                    End main title

                                                    -->
                                                    <!--

                                                    Content

                                                    -->
                                                    <div class="content">
                                                        <!--

                                                        Block content

                                                        -->
                                                        <div class="block-content margBSmall"></div>
                                                        <!--

                                                        End block content

                                                        -->
                                                        <!--

                                                        Block content

                                                        -->
                                                        <div class="block-content">
                                                            <div class="info">
                                                                <!--

                                                                Row

                                                                -->
                                                                <div class="row">
                                                                    ::before
                                                                    <div class="col-md-6"></div>
                                                                    <div class="col-md-6">
                                                                        <ul class="info-list">
                                                                            <li></li>
                                                                            <li>
                                                                                <span class="inf">

                                                                                Phone

                                                                                </span>
                                                                                <span class="value">

                                                                                + 123 456 789 456

                                                                                </span>
                                                                            </li>
                                                                            <li>
                                                                                <span class="inf">

                                                                                Skype

                                                                                </span>
                                                                                <span class="value">

                                                                                Carlose_Smith

                                                                                </span>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    ::after
                                                                </div>
                                                                <!--

                                                                End row

                                                                -->
                                                            </div>
                                                        </div>
                                                        <!--

                                                        End block content

                                                        -->
                                                    </div>
                                                    <!--

                                                    End content

                                                    -->
                                                    <!--

                                                    Main title

                                                    -->
                                                    <div class="main-title">
                                                        <h1>

                                                        professional skills

                                                        </h1>
                                                        <div class="divider"></div>
                                                    </div>
                                                    <!--

                                                    End main title

                                                    -->
                                                    <!--

                                                    Content

                                                    -->
                                                    <div class="content">
                                                        <!--

                                                        Block content

                                                        -->
                                                        <div class="block-content margBMedium">
                                                            <!--

                                                            Skill design

                                                            -->
                                                            <div class=" skill des">
                                                                <!--

                                                                Row

                                                                -->
                                                                <div class="row ">
                                                                    ::before
                                                                    <div class="vc">
                                                                        <div class="col-md-11">
                                                                            <ul class="skills-list clearfix">
                                                                                ::before
                                                                                <li>
                                                                                    <h4>

                                                                                    Photoshop

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 75%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <h4>

                                                                                    Illustrator

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 85%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <h4>

                                                                                    Indesign

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 70%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                ::after
                                                                            </ul>
                                                                        </div>
                                                                        <div class="col-md-1">
                                                                            <div class="title des"></div>
                                                                        </div>
                                                                    </div>
                                                                    ::after
                                                                </div>
                                                                <!--

                                                                End row

                                                                -->
                                                            </div>
                                                            <!--

                                                            End skill design

                                                            -->
                                                        </div>
                                                        <!--

                                                        End block content

                                                        -->
                                                        <!--

                                                        Block content

                                                        -->
                                                        <div class="block-content margBMedium">
                                                            <!--

                                                            Skill design

                                                            -->
                                                            <div class=" skill dev">
                                                                <!--

                                                                Row

                                                                -->
                                                                <div class="row">
                                                                    ::before
                                                                    <div class="vc">
                                                                        <div class="col-md-11">
                                                                            <ul class="skills-list clearfix">
                                                                                ::before
                                                                                <li>
                                                                                    <h4>

                                                                                    Html/css

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 90%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <h4>

                                                                                    javascript

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 75%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <h4>

                                                                                    php/mysql

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 90%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                ::after
                                                                            </ul>
                                                                        </div>
                                                                        <div class="col-md-1">
                                                                            <div class="title dev"></div>
                                                                        </div>
                                                                    </div>
                                                                    ::after
                                                                </div>
                                                                <!--

                                                                End row

                                                                -->
                                                            </div>
                                                            <!--

                                                            End skill design

                                                            -->
                                                        </div>
                                                        <!--

                                                        End block content

                                                        -->
                                                        <!--

                                                        Block content

                                                        -->
                                                        <div class="block-content">
                                                            <!--

                                                            Skill design

                                                            -->
                                                            <div class=" skill prs">
                                                                <!--

                                                                Row

                                                                -->
                                                                <div class="row ">
                                                                    ::before
                                                                    <div class="vc">
                                                                        <div class="col-md-11">
                                                                            <ul class="skills-list clearfix">
                                                                                ::before
                                                                                <li>
                                                                                    <h4>

                                                                                    Responsible

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 85%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <h4>

                                                                                    Creative

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 75%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                <li>
                                                                                    <h4>

                                                                                    Multitasking

                                                                                    </h4>
                                                                                    <div class="progress">
                                                                                        <div class="percentage" style="width: 90%;"></div>
                                                                                    </div>
                                                                                </li>
                                                                                ::after
                                                                            </ul>
                                                                        </div>
                                                                        <div class="col-md-1"></div>
                                                                    </div>
                                                                    ::after
                                                                </div>
                                                                <!--

                                                                End row

                                                                -->
                                                            </div>
                                                            <!--

                                                            End skill design

                                                            -->
                                                        </div>
                                                        <!--

                                                        End block content

                                                        -->
                                                    </div>
                                                    <!--

                                                    End content

                                                    -->
                                                    <!--

                                                    Main title

                                                    -->
                                                    <div class="main-title"></div>
                                                    <!--

                                                    End main title

                                                    -->
                                                    <!--

                                                    Content

                                                    -->
                                                    <div class="content"></div>
                                                    <!--

                                                    End content

                                                    -->
                                                    <!--

                                                    Main title

                                                    -->
                                                    <div class="main-title"></div>
                                                    <!--

                                                    End main title

                                                    -->
                                                    <!--

                                                    Content

                                                    -->
                                                    <div class="content"></div>
                                                    <!--

                                                    End content

                                                    -->
                                                    <!--

                                                    Main title

                                                    -->
                                                    <div class="main-title"></div>
                                                    <!--

                                                    End main title

                                                    -->
                                                    <!--

                                                    Content

                                                    -->
                                                    <div class="content"></div>
                                                    <!--

                                                    End content

                                                    -->
                                                    <!--

                                                    Main title

                                                    -->
                                                    <div class="main-title"></div>
                                                    <!--

                                                    End main title

                                                    -->
                                                    <!--

                                                    Content

                                                    -->
                                                    <div class="content"></div>
                                                    <!--

                                                    End content

                                                    -->
                                                    <!--

                                                    Button

                                                    -->
                                                    <div class="button margTop ofsInTop tCenter"></div>
                                                    <!--

                                                    End button

                                                    -->
                                                </div>
                                                <!--

                                                End about

                                                -->
                                            </section>
                                            <!--

                                            End about tab

                                            -->
                                            <!--

                                            Portfolio Tab

                                            -->
                                            <section id="portfolio" class="bgWhite ofsInBottom" style="display: none;"></section>
                                            <!--

                                            End portfolio tab

                                            -->
                                            <!--

                                            Blog Tab

                                            -->
                                            <section id="blog" class="bgWhite ofsInBottom" style="display: none;"></section>
                                            <!--

                                            End blog tab

                                            -->
                                            <!--

                                            Contact Tab

                                            -->
                                            <section id="contact" class="bgWhite ofsInBottom" style="display: none;"></section>
                                            <!--

                                            End contact tab

                                            -->
                                        </div>
                                        <!--

                                        End right content

                                        -->
                                        ::after
                                    </div>
                                    <!--

                                    End  row

                                    -->
                                    ::after
                                </div>
                                <!--

                                End  container

                                -->
                            </div>
                            <!--

                            End wrapper

                            -->
                            <!--

                            Javascript

                            -->
                            <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
                            <script type="text/javascript" src="js/jquery-migrate-1.2.1.js"></script>
                            <script type="text/javascript" src="js/owl.carousel.js"></script>
                            <script type="text/javascript" src="js/jquery.magnific-popup.js"></script>
                            <script type="text/javascript" src="js/jquery.easytabs.min.js"></script>
                            <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
                            <script type="text/javascript" src="js/modernizr.js"></script>
                            <script type="text/javascript" src="js/placeholders.min.js"></script>
                            <script src="js/Switcher/switcher.js" type="text/javascript"></script>
                            <script type="text/javascript" src="js/script.js"></script>
                            <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
                            <script>

                            (function($) { "use strict"; $(document).read…

                            </script>
                            <!--

                             Google analytics 

                            -->
                            <!--

                             End google analytics 

                            -->
                        </body>
                    </html>
                </html>
            </iframe>
            <script>

            $(function(){viewloader.execute(Views);});

            </script>
            <script>

            // Google Analytics Tracking Code (function (…

            </script>
            <script>

            // GA: universal analytics link wrapper (function…

            </script>
            <script type="text/javascript">

            // Google AdWords Remarketing /* <![CDATA[ */…

            </script>
            <script src="//www.googleadservices.com/pagead/conversion.js"></script>
            <noscript>

            <div style="display:inline;"> <img height="…

            </noscript>
            <div id="intercom-setup" class="is-hidden" data-view="intercomSetup" data-should-shutdown="false" data-should-hide="true" data-intercom-settings-payload="{"app_id":"s9exa3j0"}" data-intercom-app-id="s9exa3j0"></div>
            <script type="text/javascript" src="//d3cxv97fi8q177.cloudfront.net/mediasource-A249085-fc90-4e98-904f-95b25288c53b1-c-4415.min.js"></script>
        </body>
    </html>

