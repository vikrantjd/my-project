<html>

<head>
<title> Demo </title>
<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap/js/jquery-1.11.3-jquery.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" >
  


<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 
  </head>
  
<body>


<nav class="navbar  navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">RESUME MAKER</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home <span class="sr-only">(current)</span></a></li>
 
      
      </ul>
    
   
    </div>
  </div>
</nav>


<div class="container">

<ul class="breadcrumb">
  <li><a href="#">About Me</a></li>
  <li><a href="#">Experience</a></li>
  <li class="active">Education</li>
   <li class="active">Skill</li>
    <li class="active">Hobbies</li>
</ul>
</ul>
</ul>

<form class="form-horizontal">
  <fieldset>
    <legend>Education</legend>
    <div class="form-group ">
      <label for="inputEmail" class="col-sm-4 control-label">School Name</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="School Name"  name="School Name" type="text">
      </div>
    </div>
    <div class="form-group">
      <label for="inputPassword" class="col-sm-4 control-label">School Location</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputPassword" placeholder="School Location"  name="School Location" type="text">
       
      </div>
    </div>
	
	<div class="form-group">
      <label for="inputEmail" class="col-sm-4 control-label">Degree</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Degree"name="Degree" type="text">
      </div>
	  </div>
	  <div class="form-group">
      <label for="inputEmail" class="col-sm-4 control-label">Field Of Study</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Field Of Study"name="Field Of Study" type="text">
      </div>
	  </div>
	   <div class="form-group">
      <label for="inputEmail" class="col-sm-4 control-label">Gradution</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Gradution"name="Gradution" type="text">
      </div>
	  </div>
	    <div class="form-group">
      <label for="inputEmail" class="col-sm-4 control-label">Degree</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Degree"name="Degree" type="text">
      </div>
	  </div>
	  
	  
	  
   
	  <div class="form-group">
      <div class="col-sm-8 col-sm-offset-4">
        <button type="reset" class="btn btn-default">Cancel</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
	</div>
	


 <footer class="  footer text-center" style="  background-color:  #EB6864; padding-top: 60px; padding-bottom:20px;">
    
      
        <p class="text-muted " style="    color: #fff; font-size: 15px;">  Copyright &copy; RESUME MAKER  2016  </p>

    </footer>

	
</body>
</html>

