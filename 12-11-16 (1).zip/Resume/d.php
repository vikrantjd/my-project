<head>
  <meta charset="utf-8">
  <title>JQuery Calendar Demo</title>
  <link rel="stylesheet" href="css/style.css" />
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <script type="text/javascript" src="js/calendar.js"></script>
</head>
<body>
  

    <div><h3>Date Picker<h3></div>
    <input class="date-picker" type="text"/>
    <div>
      
</body>
