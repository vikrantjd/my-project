<html>

<head>
<title> Demo </title>
<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="bootstrap/js/jquery-1.11.3-jquery.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" >



<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>

  </head>
  
<body>


<nav class="navbar  navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">RESUME MAKER</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home <span class="sr-only">(current)</span></a></li>
 
      
      </ul>
    
   
    </div>
  </div>
</nav>
<div class="container">

<ul class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">Library</a></li>
  <li class="active">Data</li>
</ul>
<form class="form-horizontal">
<fieldset>
    <legend>ABOUT ME</legend>
	<div class="form-group ">
      <label for="inputEmail" class="col-sm-4 control-label">Name</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Name"  name="Name" type="text">
      </div>
    </div>
	<div class="form-group ">
      <label for="inputEmail" class="col-sm-4 control-label">Address</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Address"  name="Address" type="text">
      </div>
    </div>
	<div class="form-group ">
      <label for="inputEmail" class="col-sm-4 control-label">Email</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Email"  name="Email" type="text">
      </div>
    </div>
	
	<div class="form-group ">
      <label for="inputEmail" class="col-sm-4 control-label">Mobile No</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Mobile No"  name="Mobile No" type="text">
      </div>
    </div>
	<div class="form-group ">
      <label for="inputEmail" class="col-sm-4 control-label">Phon No</label>
      <div class="col-sm-4">
        <input class="form-control" id="inputEmail" placeholder="Phon No"  name="Phon No" type="text">
      </div>
    </div>
	
	<div class="radio">
  <label><input type="radio" class="col-sm-4 control-label" name="optradio">Male</label>
   <div class="col-sm-4">
   </div>
   </div>
<div class="radio">
  <label><input type="radio"class="col-sm-4 control-label" name="optradio">Female</label>
     <div class="col-sm-4">
</div>
</div>
 <div class="form-group">
      <label for="inputEmail" class="col-sm-4 control-label">Date Of Birth</label>
      <div class="col-sm-4">
        <input class="form-control" id="datepicker"   name="Year" type="text">
      </div>
	  </div>
	  </fieldset>
	  </form>
	  </body>
	  </html>
	
	



